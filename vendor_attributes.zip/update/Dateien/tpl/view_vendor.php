<?php
/* ###VERSIONSBLOCKINLCUDE### */


require_once 'sys/lib.vendor.php';
require_once 'sys/lib.vendor.category.php';
require_once 'sys/lib.vendor.gallery.php';
require_once 'sys/lib.vendor.place.php';
require_once 'sys/lib.article.php';

$vendorManagement = VendorManagement::getInstance($db);
$vendorCategoryManagement = VendorCategoryManagement::getInstance($db);
$vendorGalleryManagement = VendorGalleryManagement::getInstance($db);
$vendorPlacesManagement = VendorPlaceManagement::getInstance($db);
$articleManagement = ArticleManagement::getInstance($db);

$vendorManagement->setLangval($langval);
$vendorCategoryManagement->setLangval($langval);
$vendorPlacesManagement->setLangval($langval);
$articleManagement->setLangval($langval);

$userId = ($ar_params[2] ? (int)$ar_params[2] : null);
$tmp = $vendorManagement->fetchByUserId($userId);
$actionEx = (!empty($ar_params[3]) ? $ar_params[3] : false);
$userIsAdmin = $db->fetch_atom("SELECT count(*) FROM `role2user` ru JOIN `role` r ON r.ID_ROLE=ru.FK_ROLE AND FK_USER=".$uid." WHERE r.LABEL='Admin'");

$vendor = $vendorManagement->fetchByVendorId($tmp['ID_VENDOR']);
$vendorManagement->extendSingle($vendor);

Tools_UserStatistic::getInstance()->log_data($tmp['ID_VENDOR'], "vendor", "VIEW");

$vendorTemplate = array();

$tpl_main->addvar('newstitle',$vendor['FIRMA']);

if(!$userIsAdmin && ($userId == null || $vendor == null || !$vendorManagement->isUserVendorByUserId($userId))) { die(forward("/view_user,berni,".$userId.".htm")); }

/**
 * Info-Text anzeigen?
 */
if (!empty($actionEx)) {
    $tpl_content->addvar("info_".$actionEx, 1);
}

if ($userIsAdmin) {
    if ($_REQUEST['decline'] > 0) {
        $id_event = (int)$_REQUEST["decline"];
        $vendorManagement->adminDecline($id_event, $_REQUEST["REASON"]);
        die(forward($tpl_content->tpl_uri_action("view_vendor,".$ar_params[1].",".$userId.",declined")));
    }

    if ($_REQUEST["ajax"] == "unlockEvent") {
        header('Content-type: application/json');
        die(json_encode(array(
            "success"   => $vendorManagement->adminAccept($tmp['ID_VENDOR'])
        )));
    }
}

// Meta tags
/*
$ar_kat = $db->fetch1("SELECT s.V1, s.T1
    FROM `kat` k
      LEFT JOIN `string_kat` s ON s.S_TABLE='kat' AND s.FK=k.ID_KAT
        AND s.BF_LANG=if(s.BF_LANG & ".$langval.", ".$langval.", 1 << floor(log(k.BF_LANG_KAT+0.5)/log(2)))
    WHERE k.ID_KAT=".$id_kat."");
$article_kat = $ar_kat["V1"];
list($article_kat_keywords, $article_kat_meta) = explode("||||", $ar_kat["T1"]);
*/

// Template aufbereiten
foreach($vendor as $key=>$value) { $vendorTemplate['VENDOR_'.$key] = $value; }

if($vendorTemplate['VENDOR_CHANGED'] == '0000-00-00 00:00:00') {
    $vendorTemplate['VENDOR_CHANGED'] = 0;
}

// Kategorie Liste
$categories = $vendorCategoryManagement->fetchAllVendorCategoriesByVendorId($vendor['ID_VENDOR']);
$tpl_categories = new Template($ab_path."tpl/".$s_lang."/vendor.row.categories.htm");
$tpl_categories->addlist("categories", $categories, $ab_path.'tpl/'.$s_lang.'/vendor.row.categories.row.htm');
$vendorTemplate['VENDOR_CATEGORIES'] = $tpl_categories->process();

// Gallerie
$galleries = $vendorGalleryManagement->fetchAllByUserId($vendor['FK_USER']);
foreach($galleries as $key => $gallery) {
    $galleries[$key]['FILENAME'] = 'cache/vendor/gallery/'.$gallery['FILENAME'];
}
$tpl_content->addlist("VENDOR_GALLERY", $galleries, $ab_path.'tpl/'.$s_lang.'/view_vendor.gallery.htm');

// Gallerie Video
$galleryVideos = $vendorGalleryManagement->fetchAllVideosByUserId($vendor['FK_USER']);

$tpl_content->addlist("VENDOR_GALLERY_VIDEO", $galleryVideos, $ab_path.'tpl/'.$s_lang.'/view_vendor.gallery_video.htm');


//suchwörter

 $vendorSearchWords = $vendorManagement->fetchAllSearchWordsByUserIdAndLanguage($vendor['FK_USER'], $s_lang);
    $tpl_content->addlist("VENDOR_KEYWORDS", $vendorSearchWords, $ab_path.'tpl/'.$s_lang.'/vendor-searchword.row.htm');


// Places
$places = $vendorPlacesManagement->fetchAllByUserId($vendor['FK_USER']);
$tpl_content->addvar("JSON_VENDOR_PLACES", json_encode($places));
$tpl_content->addlist("VENDOR_PLACES", $places, $ab_path.'tpl/'.$s_lang.'/view_vendor.place.htm');

$vendorTemplate['VENDOR_LOGO'] = ($vendorTemplate['VENDOR_LOGO'] != "")?'cache/vendor/logo/'.$vendorTemplate['VENDOR_LOGO']:null;
$vendorTemplate['VENDOR_DESCRIPTION'] = $vendorManagement->fetchVendorDescriptionByLanguage($vendor['ID_VENDOR']);
$vendorTemplate['USER_ID_USER'] = $vendor['FK_USER'];
$vendorTemplate['MODERATED'] = $vendor['MODERATED'];
$vendorTemplate['DECLINE_REASON'] = $vendor['DECLINE_REASON'];
$vendorTemplate['active_vendor'] = true;

// TODO: Schönere Lösung implementeren

// Read default meta tags
$article_kat_meta = $tpl_main->vars['metatags'];

// Generate specific meta description
$meta_description = trim(strip_tags($vendorTemplate['VENDOR_DESCRIPTION']));
if (strlen($meta_description) > 160) {
	// Text kürzen auf 160-200 Zeichen
	$meta_description_len = strrpos(substr($meta_description, 0, 200), " ");
	$meta_description = $vendor['FIRMA']." ".substr($meta_description, 0, $meta_description_len);
}
if (!empty($meta_description)) {
    // Replace default description with the speific one generated
	$article_kat_meta = preg_replace('/(<meta name="description" content=)"(.*)"(>)/i', '$1"'.$meta_description.'"${3}', $article_kat_meta);
}

// Generate specific meta keywords
$meta_keywords = array();
foreach ( $vendorSearchWords as $keyword ) {
    array_push($meta_keywords, $keyword['wort']);
}

if (!empty($meta_keywords)) {
    $meta_keywords = implode(",",$meta_keywords);
    $article_kat_meta = preg_replace('/(<meta name="keywords" content=)"(.*)"(>)/i', '$1"'.$meta_keywords.'"${3}', $article_kat_meta);   
}

// Replace the default meta tags in the template
$tpl_main->vars['metatags'] = $article_kat_meta;
// ------

// User Einstellungen
$user  = $db->fetch1("select VORNAME as USER_VORNAME, NACHNAME as USER_NACHNAME, NAME as USER_NAME, FIRMA as USER_FIRMA, CACHE as USER_CACHE, STAMP_REG as USER_STAMP_REG, LASTACTIV as USER_LASTACTIV, URL as USER_URL, STRASSE as USER_STRASSE , PLZ as USER_PLZ, ORT as USER_ORT, ID_USER as USER_ID_USER, UEBER as USER_UEBER, ROUND(RATING) as USER_lastrate,TIMESTAMPDIFF(YEAR,GEBDAT,CURDATE()) as USER_age, TEL as USER_TEL from user where ID_USER=". $vendor['FK_USER']); // Userdaten lesen
include_once ($GLOBALS['nar_systemsettings']['SITE']['USER_PATH'].$user['USER_CACHE']."/".$vendor['FK_USER']."/useroptions.php");

$tpl_content->addvar("VENDOR_ALLOW_CONTACS",$useroptions['ALLOW_CONTACS']);
$tpl_content->addvar("VENDOR_ALLOW_CONTACS",$useroptions['ALLOW_CONTACS']);
$tpl_content->addvar("VENDOR_ALLOW_ADD_USER_CONTACT",$useroptions['ALLOW_ADD_USER_CONTACT']);
$tpl_content->addvar("isuser", ($uid > 0)?1:0);
$tpl_content->addvar("comments_enabled", ($nar_systemsettings["MARKTPLATZ"]["ALLOW_COMMENTS_VENDOR"] ? true : false));
$tpl_content->addvar("vendors_admin_moderated", ($nar_systemsettings["MARKTPLATZ"]["MODERATE_VENDORS"] ? true : false));
$tpl_content->addvars($vendorTemplate);

$tpl_content->addvar("USER_IS_ADMIN", $userIsAdmin);
$tpl_content->addvar("MODERATED", $vendorTemplate['MODERATED']);
if ($article_data_master['MODERATED'] == 2) {
    $tpl_content->addvar("DECLINE_REASON", $vendorTemplate['DECLINE_REASON']);
}

$cachedir = $GLOBALS['ab_path']."cache/vendor/vendor_details";
if (!is_dir($cachedir)) {
	mkdir($cachedir,0777,true);
}
$cachefile_vendor_details = $cachedir."/".$GLOBALS['s_lang']."."."vendor_details_".$vendor["USER_ID"]."_".$vendor["ID_VENDOR"].".htm";
$cacheFileLifeTime = $GLOBALS['nar_systemsettings']['CACHE']['LIFETIME_CATEGORY'];
$modifyTime = @filemtime($cachefile_vendor_details);
$diff = ((time() - $modifyTime) / 60);
if (($diff > $cacheFileLifeTime) || !file_exists($cachefile_vendor_details)) {
	$vendor_categories_flatten = array();
	foreach ( $categories as $row ) {
		array_push($vendor_categories_flatten,$row["FK_KAT"]);
	}
	$vendorId = $vendor["ID_VENDOR"];
	$vendorGroups = $vendorManagement->getData_FieldsGroups();
	$arVendorFieldsGrouped = array();
	$arVendorFieldsHtml = array();
	$langval = $GLOBALS["lang_list"][$s_lang]["BITVAL"];

	foreach ( $vendorGroups as $groupIndex => $groupId ) {
		if (((int)$groupId == 0) && ($groupId !== null)) {
			continue;
		}
		$idGroup = (int)$groupId;
		$arVendorFields = $vendorManagement->getFields(
			$idGroup > 0 ? $idGroup : null,
			$vendor_categories_flatten,
			$s_lang
		);
		foreach ($arVendorFields as $fieldIndex => $fieldDetails) {
			$fieldName = $fieldDetails["F_NAME"];
			$fieldValue = $vendorManagement->getData_Vendor($fieldName,$vendorId);
			// Check if field is visible
			if (($fieldValue === null) || ($fieldDetails["IS_SPECIAL"])) {
				continue;
			}
			// Convert value (default types)
			switch ($fieldDetails["F_TYP"]) {
				case "LIST":
					if ($fieldValue > 0) {
						$fieldValue = $fieldDetails["VALUE"] = $db->fetch_atom("
			            SELECT V1
			            FROM liste_values l
			              LEFT JOIN string_liste_values s ON
			              s.FK=l.ID_LISTE_VALUES AND s.S_TABLE='liste_values' AND
			              s.BF_LANG=if(l.BF_LANG_LISTE_VALUES & ".$langval.", ".$langval.", 1 << floor(log(l.BF_LANG_LISTE_VALUES+0.5)/log(2)))
			            WHERE l.FK_LISTE=".$fieldDetails["FK_LISTE"]." AND l.ID_LISTE_VALUES=".(int)$fieldValue
						);
						$fieldDetails["IS_SET"] = 1;
					} else {
						$fieldDetails["IS_SET"] = 0;
					}
					break;
				case "MULTICHECKBOX":
				case "MULTICHECKBOX_AND":
					$checkIdValues = trim($fieldValue, "x");
					if ($checkIdValues != "") {
						$arCheckValues = explode("x", $checkIdValues);

						$arCheckNames = $db->fetch_nar(
							"SELECT sl.V1 FROM `liste_values` l
	                    LEFT JOIN `string_liste_values` sl ON sl.S_TABLE='liste_values' AND sl.FK=l.ID_LISTE_VALUES
	                      AND sl.BF_LANG=if(l.BF_LANG_LISTE_VALUES & " . $langval . ", " . $langval . ", 1 << floor(log(l.BF_LANG_LISTE_VALUES+0.5)/log(2)))
	                    WHERE l.ID_LISTE_VALUES IN (".mysql_real_escape_string(implode(", ", $arCheckValues)).")");
						$fieldDetails["VALUE"] = implode(", ", array_keys($arCheckNames));
						$fieldDetails["IS_SET"] = 1;
					} else {
						$fieldDetails["IS_SET"] = 0;
					}
					break;
				case "DATE":
					$timeValue = strtotime($fieldValue);
					$fieldDetails['IS_SET'] = ($timeValue !== false ? 1 : 0);
					$fieldDetails["VALUE"] = date("d.m.Y", $timeValue);
					break;
				case "HTMLTEXT":
					$fieldDetails['IS_SET'] = 0;
					$fieldDetails["VALUE"] = $fieldValue;
					if (true) {
						$arVendorFieldsHtml[] = $fieldDetails;
					}
					break;
				default:
					$fieldDetails["VALUE"] = $fieldValue;
					$fieldDetails["IS_SET"] = ($fieldDetails["VALUE"] == "" ? 0 : 1);
					break;
			}
			// Add to grouped array
			if (!array_key_exists($idGroup, $arVendorFieldsGrouped)) {
				$arVendorFieldsGrouped[$idGroup] = array();
			}
			$arVendorFieldsGrouped[$idGroup][] = $fieldDetails;
		}
	}
	$arVendorFieldsTpl = array();

	if (!empty($arVendorFieldsGrouped[0])) {
		$tplGroupGeneral = new Template("tpl/".$s_lang."/vendor_details.group.htm");
		$tplGroupGeneral->addlist_fast('liste', $arVendorFieldsGrouped[0], 'tpl/'.$s_lang.'/vendor_details.group.row.htm');
		$arVendorFieldsTpl[] = $tplGroupGeneral;
		unset($arVendorFieldsGrouped[0]);
	}
	$arFieldGroupIds = array_keys($arVendorFieldsGrouped);
	if (!empty($arFieldGroupIds)) {
		$arFieldGroupList = $db->fetch_table("
		SELECT t.ID_FIELD_GROUP, s.V1
		FROM `field_group` t
		LEFT JOIN string_app s ON s.S_TABLE='field_group' AND s.FK=t.ID_FIELD_GROUP
			AND s.BF_LANG=if(t.BF_LANG_APP & ".$langval.", ".$langval.", 1 << floor(log(t.BF_LANG_APP+0.5)/log(2)))
		WHERE ID_FIELD_GROUP IN (".implode(",", $arFieldGroupIds).")
		ORDER BY t.F_ORDER");

		foreach ($arFieldGroupList as $groupIndex => $groupDetails) {
			$tplGroup = new Template("tpl/".$s_lang."/vendor_details.group.htm");
			$tplGroup->addvars($groupDetails);
			$tplGroup->addlist_fast('liste', $arVendorFieldsGrouped[$groupDetails['ID_FIELD_GROUP']], 'tpl/'.$s_lang.'/vendor_details.group.row.htm');
			$arVendorFieldsTpl[] = $tplGroup;
		}
	}
	if (!empty($arVendorFieldsHtml)) {
		foreach ($arVendorFieldsHtml as $fieldIndex => $fieldDetails) {
			$tplHtmlField = new Template("tpl/".$s_lang."/vendor_details.fields.row_htmltext.htm");
			$tplHtmlField->addvars($fieldDetails);
			$arVendorFieldsTpl[] = $tplHtmlField;
		}
	}
	$tpl_content->addvar("fields", $arVendorFieldsTpl);
	file_put_contents($cachefile_vendor_details, $arVendorFieldsTpl);
}
else {
	$tpl_content->addvar(
		"fields",
		file_get_contents($cachefile_vendor_details)
	);
}
//............


