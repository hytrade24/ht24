<?php
/* ###VERSIONSBLOCKINLCUDE### */


require_once 'sys/lib.vendor.php';
require_once 'sys/lib.vendor.category.php';

$userId = $uid;
$vendorManagement = VendorManagement::getInstance($db);
$vendorCategoryManagement = VendorCategoryManagement::getInstance($db);

$vendor = $vendorManagement->fetchByUserId($userId);
$vendorId = $vendor['ID_VENDOR'];

if (!empty($ar_params[1])) {
    $tpl_content->addvar("NOTICE_".strtoupper($ar_params[1]), 1);
}

if(isset($_POST) && $_POST['DO'] == 'SAVE') {
    $err = array();

    if (!empty($err)) {
        $tpl_content->addvar("errors", get_messages("ANBIETER", implode(',', $err)));
        $tpl_content->addvar("VENDOR_DO_ENABLE", 1);
        $_POST['STATUS'] = 0;
    }
    else {
        $vendor_master_row = array(
            "ID_VENDOR_MASTER"  =>  $vendorId
        );

        foreach ( $_POST["tmp_type"] as $key => $row ) {
            $vendor_master_row[$key] = mysql_real_escape_string($_POST[$key]);
        }
        $sql = 'SELECT *
                    FROM vendor_master v
                    WHERE v.ID_VENDOR_MASTER = ' . $vendorId;
        $result = $db->fetch1( $sql );
        if ( is_array($result) ) {//use update method
	        $result = $db->update("vendor_master",$vendor_master_row);
        }
        else {//use custom query
            $query = 'INSERT INTO vendor_master ('.implode(",",array_keys($vendor_master_row)).')
                        VALUES
                      ("'.implode('","',array_values($vendor_master_row)).'")';

            $result = $db->querynow( $query );
        }

        $vendor = $vendorManagement->fetchByUserId( $userId );
    }
}

$sql = 'SELECT v.FK_KAT
            FROM vendor_category v
            WHERE v.FK_VENDOR = ' . $vendorId;

$vendor_categories = $db->fetch_table( $sql );

$vendor_categories_flatten = array();

foreach ( $vendor_categories as $row ) {
    array_push($vendor_categories_flatten,$row["FK_KAT"]);
}

$tpl_content->isTemplateRecursiveParsable = true;
$tpl_content->isTemplateCached = true;

$arInputBlocks = CategoriesBase::getInputFieldsCache($vendor_categories_flatten, $vendor);

$tpl_content->addvar("vendor_details",$arInputBlocks);

?>
