<?php

global $db;

$sql = 'SELECT t.ID_TABLE_DEF
			FROM table_def t
			WHERE t.T_NAME = "vendor_master"';

$ID_VENDOR_MASTER = $db->fetch_atom( $sql );

$sql = "INSERT INTO `field_def` (`NO_CHANGE`, `BF_LANG_FIELD_DEF`, `FK_TABLE_DEF`, `FK_LISTE`, `FK_FIELD_GROUP`, `IS_MASTER`, `IS_SPECIAL`, `F_TYP`, `B_SEARCH`, `B_ENABLED`, `B_NEEDED`, `B_IMPORT`, `F_NAME`, `SER_CONF`, `F_ORDER`, `F_DEC_INTERN`, `B_HDB_ENABLED`)
VALUES ('1', '128', '".$ID_VENDOR_MASTER."', '0', NULL, '1', '1', 3, '0', '1', '1', '0', 'ID_VENDOR_MASTER', NULL, '1', NULL, '1');";

$db->querynow( $sql );