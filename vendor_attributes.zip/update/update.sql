
CREATE TABLE `vendor_master` (
  `ID_VENDOR_MASTER` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`ID_VENDOR_MASTER`)
) ENGINE=InnoDB;

INSERT INTO `table_def` (`BF_LANG_APP`, `T_NAME`, `T_NAME_SHORT`, `STAMP_CREATE`, `STAMP_UPDATE`)
VALUES ('128', 'vendor_master', 'vendor', '2018-01-30 16:14:49', '2018-01-30 16:14:49');

UPDATE kat SET KAT_TABLE = 'vendor_master' WHERE ROOT = 4;
