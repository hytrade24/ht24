#!/bin/bash

PATH_PATCH=`pwd`

mkdir -p DateienBackup
cd Dateien

FILES_NEW=`find . -type f`

cd ~/workspace/ebiz-trader

for filename in $FILES_NEW; do
	cp --parents "${filename}" "${PATH_PATCH}/DateienBackup/"
	echo cp --parents "${filename}" "${PATH_PATCH}/DateienBackup/"
	#echo "TestA: $filename_new"
	#echo "TestB: $filename_old"
	#echo "TestC: $filename_old_target"
done
