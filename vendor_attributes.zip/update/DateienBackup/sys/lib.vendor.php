<?php
/* ###VERSIONSBLOCKINLCUDE### */



class VendorManagement {
	private static $db;
    private static $langval = 128;
	private static $instance = null;

	/**
	 * Singleton
	 *
	 * @param ebiz_db $db
	 * @return VendorManagement
	 */
	public static function getInstance(ebiz_db $db) {
		if (self::$instance === null) {
			self::$instance = new self();
		}
		self::setDb($db);

		return self::$instance;
	}

    public function adminAccept($vendorId) {
        $db = $this->getDb();
        $res = $db->querynow("UPDATE `vendor` SET MODERATED=1 WHERE ID_VENDOR=".(int)$vendorId);
        return $res["rsrc"];
    }

    public function adminAcceptUser($id_user) {
        global $db;
        $arEvents = $db->fetch_nar("SELECT ID_VENDOR, FK_USER FROM `vendor` WHERE FK_USER=".$id_user." AND MODERATED=0");
        foreach ($arEvents as $id_vendor => $fk_user) {
            $this->adminAccept($id_vendor);
        }
    }

    public function adminDecline($vendorId, $reason, $mail = true) {
        $db = $this->getDb();
        $res = $db->querynow("UPDATE `vendor` SET MODERATED=2, DECLINE_REASON='".mysql_real_escape_string($reason)."' WHERE ID_VENDOR=".(int)$vendorId);
        if ($mail) {
            // Notify user by email
            $arMailVendor = $this->fetchByVendorId($vendorId);
            $arMailVendor["REASON"] = (empty($reason) ? false : $reason);
            $arMailUser = $db->fetch1("SELECT * FROM `user` WHERE ID_USER=".$arMailVendor["FK_USER"]);
            sendMailTemplateToUser(0, $arMailUser["ID_USER"], "MODERATE_VENDOR_DECLINED", array_merge($arMailVendor, $arMailUser));
        }
        return $res["rsrc"];
    }

    public function adminDeclineUser($id_user, $reason) {
        global $db;
        $arEvents = $db->fetch_nar("SELECT ID_VENDOR, FK_USER FROM `vendor` WHERE FK_USER=".$id_user." AND MODERATED=0");
        foreach ($arEvents as $id_vendor => $fk_user) {
            $this->adminDecline($id_vendor, $reason, false);
        }
    }

    /**
     * @param $userId
     * @return bool
     */
	public function isUserVendorByUserId($userId) {
        $db = $this->getDb();

        $r = $db->fetch_atom("SELECT COUNT(*) FROM vendor WHERE FK_USER = '".mysql_real_escape_string($userId)."' AND STATUS = 1 AND MODERATED = 1");
        return ($r > 0);
    }

    /**
     * Baut den WHERE Teil und liefert auch die notwendigen joins.
     * Return ist ein Array mit 0 => sqlWhere und 1 => sqlJoin
     *
     * @param  array  $param
     * @param  int $status
     * @return array
     */
    public function buildWhereQueryWithJoins($param, $status = 1)
    {
        $db = $this->getDb();

        $sqlWhere = "";
        $sqlJoin = "";

        if(isset($param['ID_VENDOR']) && $param['ID_VENDOR'] != null ) { $sqlWhere .= " AND v.ID_VENDOR = '".mysql_real_escape_string($param['ID_VENDOR'])."' "; }
        if(isset($param['SEARCHVENDOR']) && $param['SEARCHVENDOR'] != null) { $sqlWhere .= " AND ((sw.wort LIKE '%".mysql_real_escape_string($param['SEARCHVENDOR'])."%') OR (v.NAME LIKE '%".mysql_real_escape_string($param['SEARCHVENDOR'])."%') OR (u.FIRMA LIKE '%".mysql_real_escape_string($param['SEARCHVENDOR'])."%')) "; }
        if(isset($param['ORT']) && $param['ORT'] != null && (!isset($param['LATITUDE']) || $param['LATITUDE'] == "")) { $sqlWhere .= " AND (p.ORT LIKE '".mysql_real_escape_string($param['ORT'])."%' OR p.PLZ LIKE '".mysql_real_escape_string($param['ORT'])."%' OR v.ORT LIKE '".mysql_real_escape_string($param['ORT'])."%' OR v.PLZ LIKE '".mysql_real_escape_string($param['ORT'])."%') "; }
        if(isset($param['PLZ']) && $param['PLZ'] != null && (!isset($param['LATITUDE']) || $param['LATITUDE'] == "")) { $sqlWhere .= " AND (p.PLZ LIKE '".mysql_real_escape_string($param['PLZ'])."%' OR v.PLZ LIKE '".mysql_real_escape_string($param['PLZ'])."%') "; }
        if(isset($param['FK_COUNTRY']) && $param['FK_COUNTRY'] != null && (!isset($param['LATITUDE']) || $param['LATITUDE'] == "")) { $sqlWhere .= " AND v.FK_COUNTRY = '".mysql_real_escape_string($param['FK_COUNTRY'])."' "; }
        if(isset($param['FK_USER']) && $param['FK_USER'] != null && (!isset($param['LATITUDE']) || $param['LATITUDE'] == "")) { $sqlWhere .= " AND v.FK_USER = '".mysql_real_escape_string($param['FK_USER'])."' "; }
        if(!isset($param['FK_USER']) && isset($param['NAME_']) && $param['NAME_'] != null && (!isset($param['LATITUDE']) || $param['LATITUDE'] == "")) { $sqlWhere .= " AND u.NAME = '".mysql_real_escape_string($param['NAME_'])."' "; }
        if(isset($param['CATEGORY']) && $param['CATEGORY'] != null) {
            $row_kat = $db->fetch1("SELECT LFT,RGT,ROOT FROM `kat` WHERE ID_KAT=" . $param['CATEGORY']);
            $ids_kats = $db->fetch_nar("
              SELECT ID_KAT
                FROM `kat`
              WHERE
                (LFT >= " . $row_kat["LFT"] . ") AND
                (RGT <= " . $row_kat["RGT"] . ") AND
                (ROOT = " . $row_kat["ROOT"] . ")
            ");

            $sqlWhere .= " AND c.FK_KAT IN (".mysql_real_escape_string(implode(',', array_keys($ids_kats))).") ";
        }
        if(isset($param['LATITUDE']) && $param['LATITUDE'] != "" && isset($param['LONGITUDE']) && $param['LONGITUDE'] != "" && isset($param['LU_UMKREIS']) && $param['LU_UMKREIS'] != "" ) {
            $radius = 6368;

            $rad_b = $param['LATITUDE'];
            $rad_l = $param['LONGITUDE'];

            $rad_l = $rad_l / 180 * M_PI;
            $rad_b = $rad_b / 180 * M_PI;

            $sqlWhere .= " AND ((
                    " . $radius . " * SQRT(ABS(2*(1-cos(RADIANS(p.LATITUDE)) *
                     cos(" . $rad_b . ") * (sin(RADIANS(p.LONGITUDE)) *
                     sin(" . $rad_l . ") + cos(RADIANS(p.LONGITUDE)) *
                     cos(" . $rad_l . ")) - sin(RADIANS(p.LATITUDE)) * sin(" . $rad_b . "))))
                ) <= " . $db->fetch_atom("select `value` from lookup where ID_LOOKUP =" . $param['LU_UMKREIS'])."
                OR (
                    " . $radius . " * SQRT(ABS(2*(1-cos(RADIANS(v.LATITUDE)) *
                     cos(" . $rad_b . ") * (sin(RADIANS(v.LONGITUDE)) *
                     sin(" . $rad_l . ") + cos(RADIANS(v.LONGITUDE)) *
                     cos(" . $rad_l . ")) - sin(RADIANS(v.LATITUDE)) * sin(" . $rad_b . "))))
                ) <= " . $db->fetch_atom("select `value` from lookup where ID_LOOKUP =" . $param['LU_UMKREIS']).")";
        }

        if(isset($param['BF_LANG']) && $param['BF_LANG'] != null) { $langval = $param['BF_LANG']; } else { $langval = $this->getLangval(); }

        if(isset($param['AD']) && is_array($param['AD']) && ((int)$param['AD']['FK_KAT'] > 0)) {
            $articleTable = $db->fetch_atom("SELECT k.KAT_TABLE FROM kat k LEFT JOIN table_def t ON k.KAT_TABLE=t.T_NAME WHERE ID_KAT=" . (int)$param['AD']['FK_KAT']);

            // ID's der Unterkategorien holen
            $row_kat = $db->fetch1("SELECT LFT,RGT,ROOT FROM `kat` WHERE ID_KAT=".(int)$param['AD']['FK_KAT']);
            $ids_kats = $db->fetch_nar("
              SELECT ID_KAT
                FROM `kat`
              WHERE
                (LFT >= ".$row_kat["LFT"].") AND
                (RGT <= ".$row_kat["RGT"].") AND
                (ROOT = ".$row_kat["ROOT"].")
              ");
            $ids_kats = "(".implode(",",array_keys($ids_kats)).")";
            // Nur in aktueller Kategorie und deren Unterkategorien suchen
            $sqlWhere .= " AND a.FK_KAT IN ".$ids_kats." AND a.STATUS&3=1 AND (a.DELETED=0) ";
            if(is_array($param['AD']['SEARCH'])) {
                foreach($param['AD']['SEARCH'] as $key=>$sval) {
                    $sqlWhere .= " AND ".$sval." ";
                }
            }

            $sqlJoin .= " JOIN `".$articleTable."` a ON a.FK_USER = u.ID_USER ";
        }
        if(isset($param['TOP'])) {
            // Nur Top-User
            $sqlWhere .= " AND u.TOP_USER=1 ";
        }

        if ($status != null) {
            $sqlWhere .= "AND v.STATUS = " . $status;
            if ($status == 1) {
                $sqlWhere .= " AND v.MODERATED=1";
            }
        } else {
            if (isset($param['STATUS']) && ($param['STATUS'] != "")) {
                $sqlWhere .= " AND v.STATUS=".(int)$param['STATUS'];
            }
            if (isset($param['MODERATED']) && ($param['MODERATED'] != "")) {
                $sqlWhere .= " AND v.MODERATED=".(int)$param['MODERATED'];
            }
        }

        return array($sqlWhere, $sqlJoin);
    }


    public function fetchAllByParam($param, $status = 1) {
        $db = $this->getDb();

        $langval = $this->getLangval();
        /**
         * @todo schlecht gelöst, Refactor Bedarf
         */

        /**
         * @todo Test 123
         */
        $t = get_language();
        $langvalAsCode = $t['0'];

        $sqlLimit = "";
        $sqlOrder = " v.ID_VENDOR ";


        if(isset($param['LIMIT']) && $param['LIMIT'] != null) {
            if(isset($param['OFFSET']) && $param['OFFSET'] != null) { $sqlLimit = ' '.mysql_real_escape_string((int) $param['OFFSET']).', '.mysql_real_escape_string((int) $param['LIMIT']).' '; } else { $sqlLimit = ' '.mysql_real_escape_string((int) $param['LIMIT']).' '; }
        }
        if(isset($param['SORT']) && isset($param['SORT_DIR'])) { $sqlOrder = $param['SORT']." ".$param['SORT_DIR']; }

        $whereQueryWithJoins = $this->buildWhereQueryWithJoins($param, $status);
        $sqlWhere = $whereQueryWithJoins[0];
        $sqlJoin = $whereQueryWithJoins[1];

        $q = "
            SELECT
                v.CHANGED,
                v.ID_VENDOR,
                v.LOGO AS VENDOR_LOGO,
                v.STATUS, v.MODERATED,
                v.ALLOW_COMMENTS,
                IF(v.NAME != '', v.NAME, u.FIRMA) AS VENDOR_FIRMA,
                IF(v.PLZ != '', v.PLZ, u.PLZ) AS VENDOR_PLZ,
                IF(v.ORT != '', v.ORT, u.ORT) AS VENDOR_ORT,
                (SELECT V1 FROM string WHERE S_TABLE = 'country' AND FK = IF(v.FK_COUNTRY != '',v.FK_COUNTRY, u.FK_COUNTRY) AND BF_LANG = '".$langval."') AS VENDOR_COUNTRY,
                IF(v.TEL != '', v.TEL, u.TEL) AS VENDOR_TEL,
                IF(v.FAX != '', v.FAX, u.FAX) AS VENDOR_FAX,
                IF(v.URL != '', v.URL, u.URL) AS VENDOR_URL,
                u.ID_USER AS USER_ID_USER,
                u.NAME AS USER_NAME,
                u.CACHE AS USER_CACHE,
                u.TOP_USER AS USER_TOP_USER,
                u.TOP_SELLER AS USER_TOP_SELLER,
                u.PROOFED AS USER_PROOFED,
                (SELECT count(*) FROM `vendor_gallery` where FK_VENDOR = v.ID_VENDOR) as COUNT_GALLERY,
                (SELECT count(*) FROM `calendar_event` where FK_REF = v.ID_VENDOR AND FK_REF_TYPE = 'user' AND PRIVACY = 1 AND IS_CONFIRMED = 1 AND STAMP_END >= now()) as COUNT_EVENTS,
                (SELECT AMOUNT FROM comment_stats WHERE FK = v.ID_VENDOR AND `TABLE` = 'vendor') as COUNT_COMMENTS,
                (SELECT T1 FROM string_vendor WHERE S_TABLE = 'vendor' AND FK = v.ID_VENDOR AND BF_LANG = if(v.BF_LANG_VENDOR & ".$langval.", ".$langval.", 1 << floor(log(v.BF_LANG_VENDOR+0.5)/log(2)))) AS VENDOR_DESCRIPTION,
                (SELECT substring(T1, 1, 200) FROM string_vendor WHERE S_TABLE = 'vendor' AND FK = v.ID_VENDOR AND BF_LANG = if(v.BF_LANG_VENDOR & ".$langval.", ".$langval.", 1 << floor(log(v.BF_LANG_VENDOR+0.5)/log(2)))) AS VENDOR_SHORT_DESCRIPTION,
                RATING
            FROM
                vendor v
            JOIN user u ON u.ID_USER = v.FK_USER
            LEFT JOIN vendor_place p ON v.ID_VENDOR = p.FK_VENDOR
            LEFT JOIN vendor_category c ON v.ID_VENDOR = c.FK_VENDOR
            LEFT JOIN searchdb_index_".$langvalAsCode." si ON (si.S_TABLE = 'vendor' AND si.FK_ID = v.ID_VENDOR)
            LEFT JOIN searchdb_words_".$langvalAsCode." sw ON sw.ID_WORDS = si.FK_WORDS
            ".$sqlJoin."
            WHERE
                1 = 1
                ".($sqlWhere?' '.$sqlWhere:'')."
            GROUP BY v.ID_VENDOR
            ORDER BY ".$sqlOrder."
            ".($sqlLimit?'LIMIT '.$sqlLimit:'')."

        ";

        #echo $q;
        // print_r($q);
        $result =  $db->fetch_table($q);
        return $result;
    }

    public function countByParam($param, $status = 1) {
            $db = $this->getDb();

            $langval = $this->getLangval();
            /**
             * @todo schlecht gelöst, Refactor Bedarf
             */
            $t = get_language();
            $langvalAsCode = $t['0'];

            $sqlLimit = "";
            $sqlWhere = "";
            $sqlJoin = "";
            $sqlOrder = " v.ID_VENDOR ";

            if(isset($param['ID_VENDOR']) && $param['ID_VENDOR'] != null ) { $sqlWhere .= " AND v.ID_VENDOR = '".mysql_real_escape_string($param['ID_VENDOR'])."' "; }
            if(isset($param['SEARCHVENDOR']) && $param['SEARCHVENDOR'] != null) { $sqlWhere .= " AND ((sw.wort LIKE '%".mysql_real_escape_string($param['SEARCHVENDOR'])."%') OR (v.NAME LIKE '%".mysql_real_escape_string($param['SEARCHVENDOR'])."%') OR (u.FIRMA LIKE '%".mysql_real_escape_string($param['SEARCHVENDOR'])."%')) "; }
            if(isset($param['ORT']) && $param['ORT'] != null && (!isset($param['LATITUDE']) || $param['LATITUDE'] == "")) { $sqlWhere .= " AND (p.ORT LIKE '".mysql_real_escape_string($param['ORT'])."%' OR p.PLZ LIKE '".mysql_real_escape_string($param['ORT'])."%' OR v.ORT LIKE '".mysql_real_escape_string($param['ORT'])."%' OR v.PLZ LIKE '".mysql_real_escape_string($param['ORT'])."%') "; }
            if(isset($param['FK_COUNTRY']) && $param['FK_COUNTRY'] != null && (!isset($param['LATITUDE']) || $param['LATITUDE'] == "")) { $sqlWhere .= " AND v.FK_COUNTRY = '".mysql_real_escape_string($param['FK_COUNTRY'])."' "; }
            if(isset($param['FK_USER']) && $param['FK_USER'] != null && (!isset($param['LATITUDE']) || $param['LATITUDE'] == "")) { $sqlWhere .= " AND v.FK_USER = '".mysql_real_escape_string($param['FK_USER'])."' "; }
            if(!isset($param['FK_USER']) && isset($param['NAME_']) && $param['NAME_'] != null && (!isset($param['LATITUDE']) || $param['LATITUDE'] == "")) { $sqlWhere .= " AND u.NAME = '".mysql_real_escape_string($param['NAME_'])."' "; }
            if(isset($param['CATEGORY']) && $param['CATEGORY'] != null) {
                $row_kat = $db->fetch1("SELECT LFT,RGT,ROOT FROM `kat` WHERE ID_KAT=" . $param['CATEGORY']);
                $ids_kats = $db->fetch_nar("
                  SELECT ID_KAT
                    FROM `kat`
                  WHERE
                    (LFT >= " . $row_kat["LFT"] . ") AND
                    (RGT <= " . $row_kat["RGT"] . ") AND
                    (ROOT = " . $row_kat["ROOT"] . ")
                ");

                $sqlWhere .= " AND c.FK_KAT IN (".mysql_real_escape_string(implode(',', array_keys($ids_kats))).") ";
            }
            if(isset($param['LATITUDE']) && $param['LATITUDE'] != "" && isset($param['LONGITUDE']) && $param['LONGITUDE'] != "" && isset($param['LU_UMKREIS']) && $param['LU_UMKREIS'] != "" ) {
                $radius = 6368;

                $rad_b = $param['LATITUDE'];
                $rad_l = $param['LONGITUDE'];

                $rad_l = $rad_l / 180 * M_PI;
                $rad_b = $rad_b / 180 * M_PI;

                $sqlWhere .= " AND ((
                        " . $radius . " * SQRT(ABS(2*(1-cos(RADIANS(p.LATITUDE)) *
                         cos(" . $rad_b . ") * (sin(RADIANS(p.LONGITUDE)) *
                         sin(" . $rad_l . ") + cos(RADIANS(p.LONGITUDE)) *
                         cos(" . $rad_l . ")) - sin(RADIANS(p.LATITUDE)) * sin(" . $rad_b . "))))
                    ) <= " . $db->fetch_atom("select `value` from lookup where ID_LOOKUP =" . $param['LU_UMKREIS'])."
                    OR (
                        " . $radius . " * SQRT(ABS(2*(1-cos(RADIANS(v.LATITUDE)) *
                         cos(" . $rad_b . ") * (sin(RADIANS(v.LONGITUDE)) *
                         sin(" . $rad_l . ") + cos(RADIANS(v.LONGITUDE)) *
                         cos(" . $rad_l . ")) - sin(RADIANS(v.LATITUDE)) * sin(" . $rad_b . "))))
                    ) <= " . $db->fetch_atom("select `value` from lookup where ID_LOOKUP =" . $param['LU_UMKREIS']).")";
            }
            if(isset($param['LIMIT']) && $param['LIMIT'] != null) {
                if(isset($param['OFFSET']) && $param['OFFSET'] != null) { $sqlLimit = ' '.mysql_real_escape_string((int) $param['OFFSET']).', '.mysql_real_escape_string((int) $param['LIMIT']).' '; } else { $sqlLimit = ' '.mysql_real_escape_string((int) $param['LIMIT']).' '; }
            }
            if(isset($param['BF_LANG']) && $param['BF_LANG'] != null) { $langval = $param['BF_LANG']; } else { $langval = $this->getLangval(); }

            if(isset($param['AD']) && is_array($param['AD']) && ((int)$param['AD']['FK_KAT'] > 0)) {
                $articleTable = $db->fetch_atom("SELECT k.KAT_TABLE FROM kat k LEFT JOIN table_def t ON k.KAT_TABLE=t.T_NAME WHERE ID_KAT=" . (int)$param['AD']['FK_KAT']);

    			// ID's der Unterkategorien holen
    			$row_kat = $db->fetch1("SELECT LFT,RGT,ROOT FROM `kat` WHERE ID_KAT=".(int)$param['AD']['FK_KAT']);
    			$ids_kats = $db->fetch_nar("
    			  SELECT ID_KAT
    			    FROM `kat`
    			  WHERE
    			    (LFT >= ".$row_kat["LFT"].") AND
    			    (RGT <= ".$row_kat["RGT"].") AND
    			    (ROOT = ".$row_kat["ROOT"].")
    			  ");
    			$ids_kats = "(".implode(",",array_keys($ids_kats)).")";
    			// Nur in aktueller Kategorie und deren Unterkategorien suchen
                $sqlWhere .= " AND a.FK_KAT IN ".$ids_kats." AND a.STATUS&3=1 AND (a.DELETED=0) ";
                if(is_array($param['AD']['SEARCH'])) {
                    foreach($param['AD']['SEARCH'] as $key=>$sval) {
                        $sqlWhere .= " AND ".$sval." ";
                    }
                }

                $sqlJoin .= " JOIN `".$articleTable."` a ON a.FK_USER = u.ID_USER ";
            }
            if(isset($param['TOP'])) {
            	// Nur Top-User
            	$sqlWhere .= " AND u.TOP_USER=1 ";
            }

            if ($status != null) {
                $sqlWhere .= "AND v.STATUS = " . $status;
                if ($status == 1) {
                    $sqlWhere .= " AND v.MODERATED=1";
                }
            } else {
                if (isset($param['STATUS']) && ($param['STATUS'] != "")) {
                    $sqlWhere .= " AND v.STATUS=".(int)$param['STATUS'];
                }
                if (isset($param['MODERATED']) && ($param['MODERATED'] != "")) {
                    $sqlWhere .= " AND v.MODERATED=".(int)$param['MODERATED'];
                }
            }

            $q = ("
                SELECT
                    SQL_CALC_FOUND_ROWS v.ID_VENDOR
                FROM
                    vendor v
                JOIN user u ON u.ID_USER = v.FK_USER
                LEFT JOIN vendor_place p ON v.ID_VENDOR = p.FK_VENDOR
                LEFT JOIN vendor_category c ON v.ID_VENDOR = c.FK_VENDOR
                LEFT JOIN searchdb_index_".$langvalAsCode." si ON (si.S_TABLE = 'vendor' AND si.FK_ID = v.ID_VENDOR)
                LEFT JOIN searchdb_words_".$langvalAsCode." sw ON sw.ID_WORDS = si.FK_WORDS
                ".$sqlJoin."
                WHERE
                    1 = 1
                    ".($sqlWhere?' '.$sqlWhere:'')."
                GROUP BY v.ID_VENDOR

            ");

            $x = $db->querynow($q);
            $y = $db->fetch_atom("SELECT FOUND_ROWS()");

            return $y;
        }

    /**
     * Holt einen Anbieter anhand einer Benutzer Id
     *
     * @throws Exception
     * @param $userId
     * @return assoc
     */
    public function fetchByUserId($userId) {
        $db = $this->getDb();
        $langval = $this->getLangval();

        $this->createVendorDbTableIfNotExistByUserId($userId);

        $vendor = $db->fetch1("
            SELECT
                v.*,
                sc.V1 AS COUNTRY
            FROM vendor v
            JOIN user u ON u.ID_USER = v.FK_USER
            LEFT JOIN string sc ON sc.FK = IF(v.FK_COUNTRY != '', v.FK_COUNTRY, u.FK_COUNTRY)
                AND sc.S_TABLE = 'country' AND sc.BF_LANG = '".$langval."'
            WHERE FK_USER = '".mysql_real_escape_string($userId)."'"
        );

        return $vendor;
    }

    /**
     * Holt einen Anbieter anhand einer Vendor Id
     *
     * @throws Exception
     * @param $userId
     * @return assoc
     */
    public function fetchByVendorId($vendorId) {
        $db = $this->getDb();

        $langval = $this->getLangval();

        $vendor = $db->fetch1($x = "
            SELECT v.CHANGED,
                v.ID_VENDOR,
                v.FK_USER,
                v.LATITUDE,
                v.LONGITUDE,
                v.STATUS,
                v.LOGO,
                v.BUSINESS_HOURS,
                v.ALLOW_COMMENTS,
                u.NAME AS USER_NAME,
                u.ID_USER AS USER_ID,
                IF(v.STRASSE != '', v.STRASSE, u.STRASSE) AS STRASSE,
                IF(v.PLZ != '', v.PLZ, u.PLZ) AS PLZ,
                IF(v.ORT != '', v.ORT, u.ORT) AS ORT,
                IF(v.PLZ != '', v.PLZ, u.PLZ) AS PLZ,
                IF(v.TEL != '', v.TEL, u.TEL) AS TEL,
                IF(v.FAX != '', v.FAX, u.FAX) AS FAX,
                IF(v.URL != '', v.URL, u.URL) AS URL,
                IF(v.NAME != '', v.NAME, u.FIRMA) AS FIRMA,
                sc.V1 AS COUNTRY,
                (SELECT count(*) FROM `vendor_gallery` where FK_VENDOR = v.ID_VENDOR) as COUNT_GALLERY,
                (SELECT count(*) FROM `calendar_event` where FK_REF = v.ID_VENDOR AND FK_REF_TYPE = 'user' AND PRIVACY = 1 AND IS_CONFIRMED = 1 AND STAMP_END >= now()) as COUNT_EVENTS,
                (SELECT AMOUNT FROM comment_stats WHERE FK = v.ID_VENDOR AND `TABLE` = 'vendor') as COUNT_COMMENTS
            FROM
                vendor v
            JOIN user u ON u.ID_USER = v.FK_USER
            LEFT JOIN string sc ON sc.FK = IF(v.FK_COUNTRY != '', v.FK_COUNTRY, u.FK_COUNTRY)
                AND sc.S_TABLE = 'country' AND sc.BF_LANG = '".$langval."'
            WHERE
                v.ID_VENDOR = '".mysql_real_escape_string($vendorId)."'
            ");

        return $vendor;
    }

    /**
     * @param $vendor
     * @return assoc
     */
    public function extendSingle(&$vendor) {
        $business_hours = @json_decode($vendor['BUSINESS_HOURS'], true);
        if (!is_array($business_hours)) {
            $business_hours = [];
        }
        $weekday_today = date('N')-1;
        foreach ($business_hours as $weekday => $weekdayHours) {
            $vendor['BUSINESS_HOURS_'.$weekday] = $weekdayHours;
            if($weekday == $weekday_today) {
                $vendor['BUSINESS_HOURS_'.$weekday.'_ACTIVE'] = 1;
                $vendor['BUSINESS_HOURS_TODAY'] = $weekdayHours;
            } else {
                $vendor['BUSINESS_HOURS_'.$weekday.'_ACTIVE'] = 0;
            }
        }
    }

    /**
     * @param $vendorList
     * @return assoc
     */
    public function extendList(&$vendorList) {
        foreach ($vendorList as $vendorIndex => $vendorDetails) {
            self::extendSingle($vendorList[$vendorIndex]);
        }
        return $vendorList;
    }

    /**
     * Speichert einen Vendor Datensatz anhand der UserId
     *
     * @param array $vendor
     * @param int $userId
     * @return bool
     */
    public function saveVendorByUserId($vendor, $userId) {
    	global $ab_path, $nar_systemsettings;
        //eventlog("info", "Vendor debug: ", "saveVendorByUserId(".$vendor.", ".$userId.")");
        $db = $this->getDb();
        $sqlSet = array();
        $validation = true;

        $tmp = $this->fetchByUserId($userId);

		$land = $db->fetch_atom("SELECT V1 FROM `string` WHERE S_TABLE='country' AND FK=".(int)$vendor["FK_COUNTRY"]." AND BF_LANG=128");
        $geoCoordinates = Geolocation_Generic::getGeolocationCached($vendor["STRASSE"], $vendor["PLZ"], $vendor["ORT"], $land);
        #die(var_dump($vendor["STRASSE"], $vendor["PLZ"], $vendor["ORT"], $land));
        if (($geoCoordinates !== null) && ($geoCoordinates !== false)) {
        	// Erfolg! Geo-Koordinaten übernehmen
        	$vendor["LATITUDE"] = $geoCoordinates["LATITUDE"];
        	$vendor["LONGITUDE"] = $geoCoordinates["LONGITUDE"];
        } else {
        	eventlog("error", "Anbieter: Fehler beim Auflösen einer Adresse!", $vendor["STRASSE"]." ".$vendor["PLZ"]." ".$vendor["ORT"].", ".$land);
        }

        $vendor['CHANGED']=date("Y-m-d H:i:s");
        if ($nar_systemsettings["MARKTPLATZ"]["MODERATE_VENDORS"]) {
            $userAutoConfirm = $db->fetch_atom("SELECT AUTOCONFIRM_VENDORS FROM `user` WHERE ID_USER=".$userId);
            $vendor['MODERATED'] = ($userAutoConfirm ? 1 : 0);
        } else {
            $vendor['MODERATED'] = 1;
        }
        if(isset($vendor['STATUS']) && $vendor['STATUS'] == '1') { $vendor['STATUS'] = 1; } else { $vendor['STATUS'] = 0; }
        if(isset($vendor['URL']) && $vendor['URL'] != "" && !preg_match("/^https?\:\/\//", $vendor['URL'])) { $vendor['URL'] = 'http://'.$vendor['URL']; }
        $vendor['ID_VENDOR'] = $tmp['ID_VENDOR'];
        $vendor['FK_USER'] = $userId;
        // Strip invalid html

        $vendorLanguages = array();
        if(is_array($vendor['T1'])) {
             foreach($vendor['T1'] as $lang => $value) {
                 $vendorLanguages[$lang] = $vendor;
                 // Remove invalid HTML before saving
                 $vendorLanguages[$lang]['T1'] = strip_tags($value, $nar_systemsettings["MARKTPLATZ"]["HTML_ALLOWED_TAGS_VENDOR"]);
                 $vendorLanguages[$lang]['BF_LANG_VENDOR'] = $lang;
             }
        }  else {
			if (!empty($vendor['T1'])) {
				// Remove invalid HTML before saving
				$vendor["T1"] = strip_tags($vendor["T1"], $nar_systemsettings["MARKTPLATZ"]["HTML_ALLOWED_TAGS_VENDOR"]);
			}
			$vendorLanguages[$this->getLangval()] = $vendor;
		}

        if($validation === true) {
        	//eventlog("info", "Vendor debug: ", var_export($vendorLanguages, true));
            foreach($vendorLanguages as $lang => $vendorLanguage) {
                $db->update("vendor", $vendorLanguage);
            }
            return true;
        } else {
            return false;
        }

        return true;
    }



    /**
     * existiert ein Eintrag in der Vendor Tabelle für ein User
     * @param $userId
     * @return bool
     */
    private function existVendorDbTableByUserId($userId) {
        $db = $this->getDb();

        $exist = $db->fetch_atom("SELECT COUNT(*) FROM vendor  WHERE FK_USER = '".mysql_real_escape_string($userId)."'");
        return ($exist > 0);
    }

    /**
     * Legt einen neuen Eintrag in der Vendor Tabelle für einen User an sofern dieser noch nicht existiert
     *
     * @param $userId
     * @return void
     */
    public function createVendorDbTableIfNotExistByUserId($userId) {
        $db = $this->getDb();

        if(!$this->existVendorDbTableByUserId($userId)) {
            $db->querynow("INSERT INTO vendor (FK_USER, BF_LANG_VENDOR) VALUES ('".$userId."', 128)");
        }
    }

    public function copyUserToVendor($userId, $status = null) {
        //eventlog("info", "Vendor debug: ", "copyUserToVendor(".$userId.", ".$status.")");
        $db = $this->getDb();
        $this->existVendorDbTableByUserId($userId);

        $user = $db->fetch1("SELECT u.* FROM user u WHERE ID_USER ='".mysql_real_escape_string($userId)."'");
        $this->saveVendorByUserId(array(
        	'NAME'			=> $user['FIRMA'],
            'STRASSE' 		=> $user['STRASSE'],
            'PLZ' 			=> $user['PLZ'],
            'ORT' 			=> $user['ORT'],
            'TEL' 			=> $user['TEL'],
            'FK_COUNTRY' 	=> $user['FK_COUNTRY'],
            'FAX' 			=> $user['FAX'],
            'URL' 			=> $user['URL'],
        	// TODO: Besser lösen als zweite Datenbank-Query
        	'STATUS'		=> ($status == null ? $db->fetch_atom("SELECT STATUS FROM `vendor` WHERE FK_USER='".(int)$userId."'") : $status)

        ), $userId);
    }

    public function fetchVendorDescriptionByLanguage($vendorId, $langval = null) {
        $db = $this->getDb();
        if($langval == null) { $langval = $this->getLangval(); }

        return $db->fetch_atom("
            SELECT
                T1
            FROM
                string_vendor s
            JOIN
                vendor p ON p.ID_VENDOR = s.FK
            WHERE
                p.ID_VENDOR = '".$vendorId."'
                AND s.BF_LANG = if(p.BF_LANG_VENDOR & ".$langval.", ".$langval.", 1 << floor(log(p.BF_LANG_VENDOR+0.5)/log(2)))
            ");

    }

    public function fetchAllSearchWordsOfAllUsersWithLanguage($language) {
        $db = $this->getDb();

        $query = "SELECT
                    w.wort, count(*) as count_keywords
                FROM
                    searchdb_index_".$language." i
                JOIN searchdb_words_".$language." w ON w.ID_WORDS = i.FK_WORDS
                WHERE
                    S_TABLE = 'vendor'
                GROUP BY w.wort
                ORDER BY count_keywords DESC
                LIMIT 30";

        return $db->fetch_table( $query );
    }

    public function fetchAllSearchWordsByUserIdAndLanguage($userId, $language) {
        $db = $this->getDb();

        $vendor = $this->fetchByUserId($userId);

        if($vendor !== null) {

            return $db->fetch_table("
                SELECT
                    w.ID_WORDS, w.wort
                FROM
                    searchdb_index_".$language." i
                JOIN searchdb_words_".$language." w ON w.ID_WORDS = i.FK_WORDS
                WHERE
                    S_TABLE = 'vendor' AND FK_ID = '".$vendor['ID_VENDOR']."'
                ORDER BY w.wort
            ");

        } else {
            return null;
        }
    }

    /**
     * Fügt ein neues Schlagwort zu einem Anbieter hinzu
     *
     * @param $searchWord
     * @param $userId
     * @param string $language
     * @return bool
     */
    public function addVendorSearchWordByUserId($searchWord, $userId, $language = "de") {
        require_once ("admin/sys/lib.search.php");

        $vendor = $this->fetchByUserId($userId);

        if($vendor !== null) {
            $doSearch = new do_search($language, true);
            $doSearch->add_new_word($searchWord, $vendor['ID_VENDOR'], "vendor");

            return true;
        }
    }

    /**
     * Löscht ein Schlagwort eines Anbieters
     *
     * @param $searchWord
     * @param $userId
     * @param string $language
     * @return bool
     */
    public function deleteVendorSearchWordByUserId($searchWord, $userId, $language = "de") {
        require_once ("admin/sys/lib.search.php");

        $vendor = $this->fetchByUserId($userId);

        if($vendor !== null) {
            $doSearch = new do_search($language, true);
            $doSearch->delete_word_from_searchindex($searchWord, $vendor['ID_VENDOR'], "vendor");

            return true;
        }
    }

	/**
	 * @return ebiz_db $db
	 */
	public function getDb() {
		return self::$db;
	}

	/**
	 * @param ebiz_db $db
	 */
	public function setDb(ebiz_db $db) {
		self::$db = $db;
	}


    public function getLangval() {
        return self::$langval;
    }
    public function setLangval($langval) {
        self::$langval = $langval;
    }

    public function enableById($id) {
        $db = $this->getDb();

        $result = $db->querynow("UPDATE vendor SET STATUS = '1' WHERE ID_VENDOR='".mysql_real_escape_string($id)."'");

        if ($result['rsrc']) {

            return true;
        }

        return false;
    }

    public function disableById($id) {
        $db = $this->getDb();

        $result = $db->querynow("UPDATE vendor SET STATUS = '0' WHERE ID_VENDOR='".mysql_real_escape_string($id)."'");

        if ($result['rsrc']) {
            return true;
        }

        return false;
    }

    /**
     * Eingaben auf Fehler überprüfen.
     *
     * @param assoc     $ar_vendor
     * @param array     $errors
     * @return bool
     */
    public function updateCheckFields($ar_vendor, &$errors) {
        if (!is_array($errors)) { $errors = array(); }
        if (empty($ar_vendor["NAME"])) {
            $errors[] = "MISSING_NAME";
        }
        return empty($errors);
    }

	private function __construct() {
	}
	private function __clone() {
	}
}
