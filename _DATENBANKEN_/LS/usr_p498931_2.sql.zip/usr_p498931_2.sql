-- phpMyAdmin SQL Dump
-- version 4.2.13.3
-- http://www.phpmyadmin.net
--
-- Host: db3866.mydbserver.com
-- Erstellungszeit: 01. Mrz 2019 um 10:40
-- Server Version: 5.7.24-27
-- PHP-Version: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `usr_p498931_2`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `access_rights`
--

CREATE TABLE IF NOT EXISTS `access_rights` (
`id` int(10) unsigned NOT NULL,
  `right` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mask` int(10) unsigned NOT NULL,
  `access_role_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `access_rights`
--

INSERT INTO `access_rights` (`id`, `right`, `mask`, `access_role_id`) VALUES
(1, 'Plugins\\Hydromot\\Project', 15, 1),
(2, 'Plugins\\Hydromot\\Lead', 15, 2),
(3, 'Plugins\\Hydromot\\LeadDocument', 15, 2),
(4, 'Plugins\\Hydromot\\UserInvite', 15, 3),
(5, 'Plugins\\Hydromot\\UserChild', 15, 3),
(6, 'Plugins\\Hydromot\\LeadOffer', 15, 2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `access_roles`
--

CREATE TABLE IF NOT EXISTS `access_roles` (
`id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ident` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `access_roles`
--

INSERT INTO `access_roles` (`id`, `created_at`, `updated_at`, `ident`, `title`, `description`) VALUES
(1, '2018-04-18 11:12:29', '2018-04-18 11:12:29', 'userInvite', 'Projekte', 'Projekte erstellen, bearbeiten und zugehörige Leads verwalten'),
(2, '2018-04-18 11:12:29', '2018-04-18 11:12:29', 'lead', 'Leads', 'Durchsuchen und Kaufen von Leads'),
(3, '2018-04-18 11:12:29', '2018-04-18 11:12:29', 'userInvite', 'Accounts verwalten', 'Erlaubt es Mitarbeiter einzuladen und zu bearbeiten');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `access_role_user`
--

CREATE TABLE IF NOT EXISTS `access_role_user` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `access_role_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=291 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `access_role_user`
--

INSERT INTO `access_role_user` (`id`, `user_id`, `access_role_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(75, 68, 1),
(76, 68, 2),
(77, 68, 3),
(90, 73, 1),
(91, 73, 2),
(92, 73, 3),
(96, 75, 1),
(97, 75, 2),
(98, 75, 3),
(99, 76, 1),
(100, 76, 2),
(101, 76, 3),
(102, 77, 1),
(103, 77, 2),
(104, 77, 3),
(135, 88, 1),
(136, 88, 2),
(137, 89, 1),
(138, 89, 2),
(139, 90, 1),
(140, 90, 2),
(141, 91, 1),
(142, 91, 2),
(143, 91, 3),
(144, 92, 1),
(145, 92, 2),
(146, 92, 3),
(147, 94, 1),
(148, 94, 2),
(149, 94, 3),
(207, 114, 1),
(208, 114, 2),
(209, 114, 3),
(216, 117, 1),
(217, 117, 2),
(218, 117, 3),
(219, 118, 1),
(220, 118, 2),
(221, 118, 3),
(222, 119, 1),
(223, 119, 2),
(224, 119, 3),
(228, 121, 1),
(229, 121, 2),
(230, 121, 3),
(231, 122, 1),
(232, 122, 2),
(233, 122, 3),
(234, 123, 1),
(235, 123, 2),
(236, 123, 3),
(249, 128, 1),
(250, 128, 2),
(251, 128, 3),
(252, 129, 1),
(253, 129, 2),
(254, 129, 3),
(258, 131, 1),
(259, 131, 2),
(260, 131, 3),
(264, 133, 1),
(265, 133, 2),
(266, 133, 3),
(267, 134, 1),
(268, 134, 2),
(269, 134, 3),
(279, 138, 1),
(280, 138, 2),
(281, 138, 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `jobs`
--

CREATE TABLE IF NOT EXISTS `jobs` (
`id` bigint(20) unsigned NOT NULL,
  `queue` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `leads`
--

CREATE TABLE IF NOT EXISTS `leads` (
`id` int(10) unsigned NOT NULL,
  `status` enum('public','exclusive','done','disabled') COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `valid_until` date DEFAULT NULL,
  `due` date DEFAULT NULL,
  `valueMin` int(10) unsigned NOT NULL,
  `valueMax` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `moderated` tinyint(1) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `quantity` int(11) DEFAULT '1',
  `declined` tinyint(1) NOT NULL DEFAULT '0',
  `declineReason` text COLLATE utf8_unicode_ci,
  `adminNotes` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB AUTO_INCREMENT=658 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `leads`
--

INSERT INTO `leads` (`id`, `status`, `user_id`, `project_id`, `title`, `description`, `valid_until`, `due`, `valueMin`, `valueMax`, `created_at`, `updated_at`, `moderated`, `category_id`, `quantity`, `declined`, `declineReason`, `adminNotes`) VALUES
(655, 'public', 128, 241, 'Testlead # 1', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', '2019-03-25', '2019-03-25', 0, 0, '2019-02-25 12:22:20', '2019-02-26 05:57:06', 0, 64585, NULL, 1, '', ''),
(656, 'public', 128, 241, 'Minimotor', 'Minimotor', '2019-03-25', '2019-03-25', 0, 0, '2019-02-25 12:23:50', '2019-02-26 05:57:02', 0, 64586, 1, 1, '', ''),
(657, 'exclusive', 128, 241, 'Minimotor 2', 'Minimotor 2', '2019-03-25', '2019-03-25', 0, 0, '2019-02-25 12:24:27', '2019-02-26 05:56:57', 0, 64586, 1, 1, '', '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `leads_articles`
--

CREATE TABLE IF NOT EXISTS `leads_articles` (
`id` int(10) unsigned NOT NULL,
  `article_trader_id` int(10) unsigned NOT NULL,
  `lead_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(10) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1445 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `leads_articles`
--

INSERT INTO `leads_articles` (`id`, `article_trader_id`, `lead_id`, `title`, `quantity`) VALUES
(1443, 376887, 656, 'Hydraulikmotor - EPMM8C', 1),
(1444, 376887, 657, 'Hydraulikmotor - EPMM8C', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `leads_documents`
--

CREATE TABLE IF NOT EXISTS `leads_documents` (
`id` int(10) unsigned NOT NULL,
  `lead_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filetype` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `disk` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'local',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `public` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `leads_images`
--

CREATE TABLE IF NOT EXISTS `leads_images` (
`id` int(10) unsigned NOT NULL,
  `lead_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filetype` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `leads_offers`
--

CREATE TABLE IF NOT EXISTS `leads_offers` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `lead_id` int(10) unsigned NOT NULL,
  `status` enum('pending','accepted','declined','withdrawn') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `priceEstimate` double(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `leads_offers_documents`
--

CREATE TABLE IF NOT EXISTS `leads_offers_documents` (
`id` int(10) unsigned NOT NULL,
  `lead_offer_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filetype` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `disk` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'local',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `leads_sellers`
--

CREATE TABLE IF NOT EXISTS `leads_sellers` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_id_contact` int(10) unsigned DEFAULT NULL,
  `lead_id` int(10) unsigned NOT NULL,
  `bought` tinyint(1) NOT NULL,
  `recommended` tinyint(1) NOT NULL,
  `ignored` tinyint(1) NOT NULL,
  `rating` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2531 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `leads_sellers`
--

INSERT INTO `leads_sellers` (`id`, `user_id`, `user_id_contact`, `lead_id`, `bought`, `recommended`, `ignored`, `rating`, `created_at`, `updated_at`) VALUES
(2529, 1, 1, 656, 0, 1, 0, NULL, '2019-02-25 12:23:50', '2019-02-25 12:23:50'),
(2530, 1, 1, 657, 0, 1, 0, NULL, '2019-02-25 12:24:27', '2019-02-25 12:24:27');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
`id` int(10) unsigned NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1103 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1073, '2014_10_12_000000_create_users_table', 1),
(1074, '2014_10_12_100000_create_password_resets_table', 1),
(1075, '2017_02_07_132642_create_access_roles', 1),
(1076, '2017_04_04_165535_create_tree_table', 1),
(1077, '2017_04_04_190726_create_navigation_table', 1),
(1078, '2017_11_27_095129_create_jobs_table', 1),
(1079, '2017_11_28_000000_create_project_table', 1),
(1080, '2017_11_29_000000_create_lead_table', 1),
(1081, '2017_11_30_000000_create_lead_article_table', 1),
(1082, '2017_11_30_000000_create_lead_document_table', 1),
(1083, '2017_11_30_000000_create_lead_image_table', 1),
(1084, '2017_11_30_000000_create_lead_seller_table', 1),
(1085, '2018_01_04_000000_update_user_table', 1),
(1086, '2018_01_22_000000_create_profile_table', 1),
(1087, '2018_01_31_000000_create_user_invite_table', 1),
(1088, '2018_02_05_000000_create_user_child_table', 1),
(1089, '2018_04_17_093500_add_lead_document_public_field', 1),
(1090, '2018_04_17_115200_create_lead_offer_table', 1),
(1091, '2018_04_17_115230_create_lead_offer_document_table', 1),
(1092, '2018_04_20_113000_update_lead_seller_table', 2),
(1093, '2018_05_09_150000_create_user_chat_table', 3),
(1094, '2018_05_09_151500_create_user_chat_message_table', 3),
(1095, '2018_05_09_162000_create_user_chat_message_document_table', 3),
(1096, '2018_05_09_164000_create_user_chat_lead_table', 3),
(1097, '2018_05_30_000000_update_lead_table_add_moderated', 4),
(1098, '2018_06_12_000000_update_lead_table_add_category', 5),
(1099, '2018_08_09_000000_update_lead_table_add_quantity', 6),
(1100, '2018_08_21_000000_update_lead_table_add_decline', 7),
(1101, '2018_08_21_000000_update_lead_table_add_notes', 8),
(1102, '2018_10_01_114300_update_lead_offer_table_allow_price_null', 9);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `navigation`
--

CREATE TABLE IF NOT EXISTS `navigation` (
`id` int(10) unsigned NOT NULL,
  `tree_node` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8_unicode_ci NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `route` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `controller` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowPost` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `navigation`
--

INSERT INTO `navigation` (`id`, `tree_node`, `title`, `description`, `keywords`, `visible`, `url`, `route`, `controller`, `allowPost`) VALUES
(1, 1, 'Startseite', 'Startseite', 'Startseite', 1, '/', 'index', NULL, 0),
(2, 2, 'Test', 'Test', 'Test', 1, '/test', 'test', NULL, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `profiles`
--

CREATE TABLE IF NOT EXISTS `profiles` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `status` enum('public','paused','disabled') COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `job_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `telephone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `xing` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `profiles`
--

INSERT INTO `profiles` (`id`, `user_id`, `status`, `first_name`, `last_name`, `job_title`, `description`, `telephone`, `mobile`, `fax`, `email`, `xing`, `linkedin`, `created_at`, `updated_at`) VALUES
(1, 1, 'public', 'Hytrade24', 'GmbH', 'CEO', 'Testbeschreibung für das Lead-Profil des Admins', '012345/67890', '0123/4567890', '012345/67899', 'jniedling@ebiz-consult.de', 'https://www.xing.com/profile/Example', 'https://www.linkedin.com/in/example/', '2018-04-18 11:12:29', '2018-10-25 08:57:49'),
(44, 68, 'public', '', '', NULL, NULL, NULL, NULL, NULL, 'argo-hytos@hytrade24.com', NULL, NULL, '2018-09-17 11:25:32', '2018-09-17 11:25:32'),
(49, 73, 'public', 'Markus', 'Ringeisen', NULL, NULL, NULL, NULL, NULL, 'Hydac@hytrade24.com', NULL, NULL, '2018-09-17 11:30:42', '2018-10-02 09:16:48'),
(51, 75, 'public', 'ABC', 'XYZ', NULL, NULL, NULL, NULL, NULL, 'jahns-hydraulik@hytrade24.com', NULL, NULL, '2018-09-17 11:33:29', '2018-09-17 11:33:29'),
(52, 76, 'public', '', '', NULL, NULL, NULL, NULL, NULL, 'Linde-Hydraulics@hytrade24.com', NULL, NULL, '2018-09-17 11:34:19', '2018-09-17 11:34:19'),
(53, 77, 'public', '', '', NULL, NULL, NULL, NULL, NULL, 'mpfiltri@hytrade24.com', NULL, NULL, '2018-09-17 11:35:03', '2018-09-17 11:35:03'),
(64, 88, 'public', 'Herr', 'Wirzberger', NULL, NULL, NULL, NULL, NULL, 'a.kloess@hytrade24.com', NULL, NULL, '2018-10-15 12:20:19', '2018-10-15 12:20:19'),
(65, 89, 'public', 'Herr', 'Goretzky', NULL, NULL, NULL, NULL, NULL, 'mail@andreaskloess.de', NULL, NULL, '2018-10-15 12:23:48', '2018-10-15 12:23:48'),
(66, 90, 'public', 'Herr', 'Drexler', NULL, NULL, NULL, NULL, NULL, 'andreas.kloess@me.com', NULL, NULL, '2018-10-15 12:24:50', '2018-10-15 12:24:50'),
(67, 91, 'public', 'René', 'Schönthaler', NULL, NULL, NULL, NULL, NULL, 'r.schoenthaler@hytrade24.com', NULL, NULL, '2018-11-02 09:58:08', '2018-11-02 09:58:08'),
(68, 92, 'public', '', '', NULL, NULL, NULL, NULL, NULL, 'x.lutz@hytrade24.com', NULL, NULL, '2018-11-02 14:43:42', '2018-11-02 14:43:42'),
(69, 94, 'public', 'ELIGIO', 'SANDRINI', NULL, NULL, NULL, NULL, NULL, 'eligio07@gmail.com', NULL, NULL, '2018-11-11 10:38:48', '2018-11-11 10:38:48'),
(89, 114, 'public', 'Benjamin', 'Walter', NULL, NULL, NULL, NULL, NULL, 'bw@walter-co.de', NULL, NULL, '2018-12-14 12:20:24', '2018-12-14 12:20:24'),
(92, 117, 'public', 'Jeannine', 'Wolf', NULL, NULL, NULL, NULL, NULL, 'Chemnitz@hydraulik-online.net', NULL, NULL, '2019-01-10 12:34:57', '2019-01-10 12:34:57'),
(93, 118, 'public', '', '', NULL, NULL, NULL, NULL, NULL, 'test@hytrade24.com', NULL, NULL, '2019-01-29 10:41:51', '2019-01-29 10:41:51'),
(96, 121, 'public', 'Frank', 'Penzersinski', NULL, NULL, NULL, NULL, NULL, 'zeppelin@hytrade24.com', NULL, NULL, '2019-02-04 15:26:15', '2019-02-04 15:26:15'),
(97, 122, 'public', '', '', NULL, NULL, NULL, NULL, NULL, 'info@ebiz-consult.de', NULL, NULL, '2019-02-06 14:04:18', '2019-02-06 14:04:18'),
(98, 123, 'public', 'Silke', 'Warnat', NULL, NULL, NULL, NULL, NULL, 's.warnat@hk-hydraulik-kontor.de', NULL, NULL, '2019-02-06 17:22:33', '2019-02-06 17:22:33'),
(103, 128, 'public', 'Jens', 'Niedling', NULL, NULL, NULL, NULL, NULL, 'jniedling@ebiz-consult.de', NULL, NULL, '2019-02-08 08:47:50', '2019-02-08 08:47:50'),
(104, 129, 'public', 'Philipp', 'Wulfhorst', NULL, NULL, NULL, NULL, NULL, 'Nils-Philipp.Wulfhorst@rotarypower.com', NULL, NULL, '2019-02-08 10:46:09', '2019-02-08 10:46:09'),
(106, 131, 'public', 'Matthias', 'Warnat', NULL, NULL, NULL, NULL, NULL, 'm.warnat@hk-hydraulik-kontor.de', NULL, NULL, '2019-02-09 10:48:33', '2019-02-09 10:48:33'),
(108, 133, 'public', 'imenso', 'dev', NULL, NULL, NULL, NULL, NULL, 'inder.imenso@gmail.com', NULL, NULL, '2019-02-11 05:59:05', '2019-02-11 05:59:05'),
(109, 134, 'public', 'Alexander', 'Weimer', NULL, NULL, NULL, NULL, NULL, 'weimer@matricks.de', NULL, NULL, '2019-02-11 15:51:47', '2019-02-11 15:51:47'),
(112, 119, 'public', 'Andreas', 'Klöss', '', 'LÖSI HYDRAULIK- HOCHWERTIG UND ZUVERLÄSSIG\r\nGemacht für höchste Anforderungen\r\nWir sind Ihr Spezialist in Sachen Hydraulik, Komponenten und Zubehör. LöSi steht für hochwertige Produkte und ausgezeichneten Service. Von uns erhalten Sie beste Unterstützung von der Projektierung bis zur Wartung. Ganz egal, ob Sie ein Kleinunternehmer sind oder ein internationaler Industriekonzern. Bei uns stehen Sie als Kunde im Mittelpunkt und werden von unseren geschulten Mitarbeitern individuell und ganzheitlich auf allen Feldern der Hydraulik beraten.', '', '', '', 'andreas.kloess@loesi.de', '', '', '2019-02-14 15:52:43', '2019-02-14 15:52:43'),
(114, 138, 'public', 'Jim', 'Bell', NULL, NULL, NULL, NULL, NULL, 'm.boeckly@hytrade24.com', NULL, NULL, '2019-02-22 12:00:18', '2019-02-22 12:00:18');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `valid_until` date DEFAULT NULL,
  `due` date DEFAULT NULL,
  `valueMin` int(10) unsigned NOT NULL,
  `valueMax` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `projects`
--

INSERT INTO `projects` (`id`, `user_id`, `title`, `description`, `valid_until`, `due`, `valueMin`, `valueMax`, `created_at`, `updated_at`) VALUES
(241, 128, 'Testprojekt', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', NULL, '2019-03-25', 0, 0, '2019-02-25 12:22:20', '2019-02-25 12:22:20');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tree`
--

CREATE TABLE IF NOT EXISTS `tree` (
`id` int(10) unsigned NOT NULL,
  `ident` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `tree`
--

INSERT INTO `tree` (`id`, `ident`) VALUES
(1, 'nav');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tree_node`
--

CREATE TABLE IF NOT EXISTS `tree_node` (
`id` int(10) unsigned NOT NULL,
  `tree` int(10) unsigned NOT NULL,
  `left` int(10) unsigned NOT NULL,
  `right` int(10) unsigned NOT NULL,
  `parent` int(10) unsigned DEFAULT NULL,
  `level` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `tree_node`
--

INSERT INTO `tree_node` (`id`, `tree`, `left`, `right`, `parent`, `level`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 2, NULL, 0, '2018-04-18 13:12:32', '2018-04-18 13:12:32'),
(2, 1, 3, 4, NULL, 0, '2018-04-18 13:12:32', '2018-04-18 13:12:32');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `trader_id` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `trader_id`) VALUES
(1, 'admin', 'info@hytrade24.com', '$2y$10$dlWQ3/mmCi5RbA5.1O8NwuZ2ktMMo/kAqzxgPVbIfVsylXaV/8AIu', 'AQSn2BcPzF7GT1JVGrY5Np1JsJF659k9Yr05N8ymcPMqhLHR9IWZ8Tl05N4x', '2018-04-18 11:12:29', '2018-10-25 08:57:49', 1),
(68, 'Argo-Hytos', 'argo-hytos@hytrade24.com', '$2y$10$UiDgE.UK6okxDiTkov6j1OkqplNpTqBnd/F8Uj1jcED8RNC9KS4A2', 'MKDVzStnWHC0hJEi7lvu2GBX7MgeomsqcamOuCPZjR2GeoFDSuhI80KP8R7s', '2018-09-17 11:25:32', '2018-09-17 11:25:32', 319),
(73, 'Hydac', 'Hydac@hytrade24.com', '$2y$10$SBdxbsNCq3gkMtMhX9MSO.AZmgjI1FdErdR15ngojLjO/rWKk6536', 'ZukWx4tpF012Dt0BrvmZMFdtRQmVfq5GyLxjRIRXfXDKTmjOrEdQTnUpfwHK', '2018-09-17 11:30:42', '2018-09-17 11:30:42', 324),
(75, 'Jahns Hydraulik', 'jahns-hydraulik@hytrade24.com', '$2y$10$NtBF9bHErileAVjSNAT7G.WIpTTlKQAqZK7bHAY8wakVu8TRhAcyG', 'RQSFUnrlAyq1SKVkrQMiRznukJdEDJCtbTnj74L3wJUUrC3fTJN1bUZewueh', '2018-09-17 11:33:29', '2018-09-17 11:33:29', 326),
(76, 'Linde Hydraulics', 'Linde-Hydraulics@hytrade24.com', '$2y$10$WT3y/FE7/TkJeblH2XBZXOEvh70X93.xmQzpbPQSHwaAtfPhkxVxO', 'OUe06SrlLqHItyALqpCdXtLSNsRCFjT4a1giXfwUOiFkvps75oYGmcQ3Iyyu', '2018-09-17 11:34:19', '2018-09-17 11:34:19', 327),
(77, 'MP Filtri', 'mpfiltri@hytrade24.com', '$2y$10$E5Cfl8g1y3IugMlntzYSnugLRXzvKEP6YiBKToXcejuh4BfWwVl0q', NULL, '2018-09-17 11:35:03', '2018-09-17 11:35:03', 328),
(88, 'Wirzberger', 'a.kloess@hytrade24.com', '$2y$10$88Sbt1U0oCMw4PkebFLET.2ggTLcmRTd9eaS3zrPWjslFbG7Qn2gi', NULL, '2018-10-15 12:20:19', '2018-10-15 12:20:19', NULL),
(89, 'Goretzky', 'mail@andreaskloess.de', '$2y$10$.ITkzxDhGoPNyrzxR/XAB.LDr60byafjCcrgUDll2hPPk9T84Esqq', NULL, '2018-10-15 12:23:47', '2018-10-15 12:23:47', NULL),
(90, 'Drexler', 'andreas.kloess@me.com', '$2y$10$2jeNyqk.GADmoPWNiZ4S1.J8y1vfDJPag6OQeO/jSOfa4en6CvLXi', '5UhkXu2jElR6gp80riJNTyfAaJVPmrgZ7gYJkkxKGAxeqs8X0YhM3rj5GV7S', '2018-10-15 12:24:50', '2018-10-15 12:24:50', NULL),
(91, 'RS', 'r.schoenthaler@hytrade24.com', '$2y$10$EWo/nZGhJlcpfDDVD.1Ur.LHqLi/DQ0SyFILOmiRhv888.1GEaOy2', 'EsnijLFyzDRmVkVLKbBGZ3lgZVFA3s4t9jIKBuNsQKvSG9yB8OcKn64tOWTH', '2018-11-02 09:58:08', '2018-11-02 09:58:08', 339),
(92, 'xaverlutz', '', '$2y$10$/yw8uzFyraaiIVhxG1dfXOAP8M7m3v8btSNZNZtGnoRNTT517ipWS', 'Y9IpDih52Am9c65D6PK6tN9p5duT3QOxdPckH8C5C1He9lNDSstKzrlSljTn', '2018-11-02 14:43:42', '2018-11-02 14:43:42', 340),
(94, 'eligio07', 'eligio07@gmail.com', '$2y$10$MCh/BnYUez/cv3PCedZY1OoJ7KP40BYEdD0gIdyP1n8xfLgffQ1cS', 'htFWHj1tqKygcKNFCz4nY1JiKA9U7UKyPyGe2KDiIaJi5zb44gCLxgCWmSDj', '2018-11-11 10:38:48', '2018-11-11 10:38:48', 342),
(114, 'BEWA', 'bw@walter-co.de', '$2y$10$IHePG1vzOAnAVfKWRGkwL.QogjIdG03YY28vfXqup9BIl4oVPNT0S', NULL, '2018-12-14 12:20:24', '2018-12-14 12:20:24', 362),
(117, 'AMRC', 'Chemnitz@hydraulik-online.net', '$2y$10$um9qlvRqsVHtrgDYz80AJuvbvMg4go6apUAu7h2c4gIGonBxIcoie', NULL, '2019-01-10 12:34:56', '2019-01-10 12:34:56', 365),
(118, 'P498931f2', 'test@hytrade24.com', '$2y$10$MRCksCLOydVCp7IdPLBFH.CQv4PxsyRNAzKB9cDtUEHx08AwP36zK', '6jqeH13CzJipbkvMaU4ZD7zuWtdKD8bOky33ahe61z1KZLxxqekGugBHkM1i', '2019-01-29 10:41:51', '2019-01-29 10:41:51', 366),
(119, 'LoSiGmbH', 'andreas.kloess@loesi.de', '$2y$10$U8q1xsX5xOiWKHnVgq5HDuTv23tMWRnwsdKser1Cjzw7D23D/ZpXq', 'XHekZBieE3xcwgHOj74eqYXuR0scYarJCEAz72jxr3PnKXx1D7telIO7HhFq', '2019-01-31 23:00:00', '2019-01-31 23:00:00', 367),
(121, 'Zeppelin', 'zeppelin@hytrade24.de', '$2y$10$SEg5CO7A/n7ey9BKPUOWQOrNsdTqYe0ZmLnyckdo.E4MxUsdRpTv6', NULL, '2019-02-04 15:26:15', '2019-02-04 15:26:15', 369),
(122, 'ebiz', 'info@ebiz-consult.de', '$2y$10$u3hN6G6O.uheg9Utx8AHl.sXHa.VSpVr38q2foX1gjxTf/X7HxWGS', 'lKVa3XBrlfkQRmwMCbMjoJFRxY2j1FBoCT9JCVocNdxMiUvgQfDgzglExtqb', '2019-02-06 14:04:18', '2019-02-06 14:04:18', 370),
(123, 'SilkeWarnat', 's.warnat@hk-hydraulik-kontor.de', '$2y$10$yzLxbh/LqsiyMKOJ/s1HSuP.UsZj4n/ZOQ8acwnfprEAsh7wiNRx2', 'OgsSXGbu0KM8ElFgGRE5dsFH3VS6IXY9k5eSW7VOChJEeul4r4L8HW2lAvAv', '2019-02-06 17:22:33', '2019-02-06 17:22:33', 371),
(128, 'DemoUser', 'jniedling@ebiz-consult.de', '$2y$10$3tUlcGGSA8XXncn4PUeT2.rE0sqCQwKrHqBBA42BB13DlEaKvZEe6', 'JWBTNoo3CmjxSEs6EiJDWJu5LReWSUME29ROcfrA203nuy7h0bttbqMp7xkE', '2019-02-08 08:47:50', '2019-02-08 08:47:50', 376),
(129, 'RotaryPower', 'Nils-Philipp.Wulfhorst@rotarypower.com', '$2y$10$cmh6tz9oZHHmzetw/rWe3Owcl6vHVEhWvkBU3BnV/47hR4rIxKWG6', NULL, '2019-02-08 10:46:09', '2019-02-08 10:46:09', 377),
(131, 'MatthiasWarnat', 'm.warnat@hk-hydraulik-kontor.de', '$2y$10$Q3El8G7r3Q9s3jijgl8EDuDIfzJ9rSWzCRL67dfgXtERZMI0Gn8da', NULL, '2019-02-09 10:48:33', '2019-02-09 10:48:33', 379),
(133, 'imenso', 'inder.imenso@gmail.com', '$2y$10$n6G/C6Qujq1f3mXcSMrIU.odIyUteBquF0sakchibpJwEo.ud0cZ6', NULL, '2019-02-11 05:59:05', '2019-02-11 05:59:05', 369),
(134, 'weimer', 'weimer@matricks.de', '$2y$10$lA1y6oJK6FbQBBI2cB86u.68LHVLNrBk9Trn2JoIqpupbe3OINBuS', 'jUhoB3LFE7NYGBBt3KxTLTisPWZcpAnIFS2Gq7M5OyOc5QC4pQvs6TB11nNC', '2019-02-11 15:51:47', '2019-02-11 15:51:47', 381),
(138, 'LosiUK', 'm.boeckly@hytrade24.com', '$2y$10$/k9SumOkdeu1KJNkoaezZuR7WpPhhnZS5I8FWqG8nJ9DQIn7U7EHe', 'qk9mvA6KhUTapZl7sDNXJb6jDPhifcZCbTDZVfHxLOOY8IsTpGHncSKpA0eI', '2019-02-22 12:00:18', '2019-02-22 12:00:18', 385);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_chats`
--

CREATE TABLE IF NOT EXISTS `user_chats` (
`id` int(10) unsigned NOT NULL,
  `user_from_id` int(10) unsigned NOT NULL,
  `user_to_id` int(10) unsigned NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_chat_leads`
--

CREATE TABLE IF NOT EXISTS `user_chat_leads` (
`id` int(10) unsigned NOT NULL,
  `user_chat_id` int(10) unsigned NOT NULL,
  `lead_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_chat_messages`
--

CREATE TABLE IF NOT EXISTS `user_chat_messages` (
`id` int(10) unsigned NOT NULL,
  `user_from_id` int(10) unsigned NOT NULL,
  `user_to_id` int(10) unsigned NOT NULL,
  `user_chat_id` int(10) unsigned NOT NULL,
  `chat_owner` tinyint(1) NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `moderated` tinyint(1) NOT NULL DEFAULT '1',
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_chat_message_documents`
--

CREATE TABLE IF NOT EXISTS `user_chat_message_documents` (
`id` int(10) unsigned NOT NULL,
  `user_chat_message_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filetype` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `disk` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'local',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_childs`
--

CREATE TABLE IF NOT EXISTS `user_childs` (
`id` int(10) unsigned NOT NULL,
  `user_parent_id` int(10) unsigned NOT NULL,
  `user_child_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `user_childs`
--

INSERT INTO `user_childs` (`id`, `user_parent_id`, `user_child_id`) VALUES
(1, 73, 88),
(2, 73, 89),
(3, 73, 90);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_invites`
--

CREATE TABLE IF NOT EXISTS `user_invites` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `greeting` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `info` text COLLATE utf8_unicode_ci NOT NULL,
  `accessRoles` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `user_invites`
--

INSERT INTO `user_invites` (`id`, `user_id`, `code`, `greeting`, `email`, `info`, `accessRoles`, `created_at`, `updated_at`) VALUES
(1, 1, '58ed7b3e', 'Mitarbeiter Test', 'jniedling@ebiz-consult.de', 'Test-Einladung', '{"1":"1","2":"1"}', '2018-10-15 10:55:57', '2018-10-15 10:55:57'),
(3, 73, NULL, 'Herr Wirzberger', 'a.kloess@hytrade24.com', 'Einladung Hr. Wirzberger', '{"1":"1","2":"1"}', '2018-10-15 12:17:38', '2018-10-15 12:20:19'),
(4, 73, NULL, 'Herr Gorecky', 'mail@andreaskloess.de', 'Einladung Herr Gorezky', '{"1":"1","2":"1"}', '2018-10-15 12:18:20', '2018-10-15 12:23:48'),
(5, 73, NULL, 'Herr Drexler', 'andreas.kloess@me.com', 'Einladung Herr Drexler', '{"1":"1","2":"1"}', '2018-10-15 12:18:52', '2018-10-15 12:24:50');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `access_rights`
--
ALTER TABLE `access_rights`
 ADD PRIMARY KEY (`id`), ADD KEY `access_rights_access_role_id_foreign` (`access_role_id`);

--
-- Indizes für die Tabelle `access_roles`
--
ALTER TABLE `access_roles`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `access_role_user`
--
ALTER TABLE `access_role_user`
 ADD PRIMARY KEY (`id`), ADD KEY `access_role_user_user_id_foreign` (`user_id`), ADD KEY `access_role_user_access_role_id_foreign` (`access_role_id`);

--
-- Indizes für die Tabelle `jobs`
--
ALTER TABLE `jobs`
 ADD PRIMARY KEY (`id`), ADD KEY `jobs_queue_index` (`queue`);

--
-- Indizes für die Tabelle `leads`
--
ALTER TABLE `leads`
 ADD PRIMARY KEY (`id`), ADD KEY `leads_status_created_at_index` (`status`,`created_at`), ADD KEY `leads_user_id_foreign` (`user_id`), ADD KEY `leads_project_id_foreign` (`project_id`), ADD KEY `leads_moderated_index` (`moderated`), ADD KEY `leads_category_id_index` (`category_id`);

--
-- Indizes für die Tabelle `leads_articles`
--
ALTER TABLE `leads_articles`
 ADD PRIMARY KEY (`id`), ADD KEY `leads_articles_lead_id_foreign` (`lead_id`);

--
-- Indizes für die Tabelle `leads_documents`
--
ALTER TABLE `leads_documents`
 ADD PRIMARY KEY (`id`), ADD KEY `lead_public` (`lead_id`,`public`);

--
-- Indizes für die Tabelle `leads_images`
--
ALTER TABLE `leads_images`
 ADD PRIMARY KEY (`id`), ADD KEY `leads_images_lead_id_foreign` (`lead_id`);

--
-- Indizes für die Tabelle `leads_offers`
--
ALTER TABLE `leads_offers`
 ADD PRIMARY KEY (`id`), ADD KEY `user_status` (`user_id`,`status`), ADD KEY `lead_status` (`lead_id`,`status`);

--
-- Indizes für die Tabelle `leads_offers_documents`
--
ALTER TABLE `leads_offers_documents`
 ADD PRIMARY KEY (`id`), ADD KEY `leads_offers_documents_lead_offer_id_foreign` (`lead_offer_id`);

--
-- Indizes für die Tabelle `leads_sellers`
--
ALTER TABLE `leads_sellers`
 ADD PRIMARY KEY (`id`), ADD KEY `leads_sellers_user_id_foreign` (`user_id`), ADD KEY `leads_sellers_lead_id_foreign` (`lead_id`), ADD KEY `leads_sellers_user_id_contact_foreign` (`user_id_contact`);

--
-- Indizes für die Tabelle `migrations`
--
ALTER TABLE `migrations`
 ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `navigation`
--
ALTER TABLE `navigation`
 ADD PRIMARY KEY (`id`), ADD KEY `navigation_tree_node_foreign` (`tree_node`);

--
-- Indizes für die Tabelle `password_resets`
--
ALTER TABLE `password_resets`
 ADD KEY `password_resets_email_index` (`email`), ADD KEY `password_resets_token_index` (`token`);

--
-- Indizes für die Tabelle `profiles`
--
ALTER TABLE `profiles`
 ADD PRIMARY KEY (`id`), ADD KEY `profiles_user_id_foreign` (`user_id`);

--
-- Indizes für die Tabelle `projects`
--
ALTER TABLE `projects`
 ADD PRIMARY KEY (`id`), ADD KEY `projects_user_id_foreign` (`user_id`);

--
-- Indizes für die Tabelle `tree`
--
ALTER TABLE `tree`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `ident` (`ident`);

--
-- Indizes für die Tabelle `tree_node`
--
ALTER TABLE `tree_node`
 ADD PRIMARY KEY (`id`), ADD KEY `tree_node_tree_foreign` (`tree`), ADD KEY `tree_node_parent_foreign` (`parent`), ADD KEY `nested_set` (`left`,`right`);

--
-- Indizes für die Tabelle `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`), ADD KEY `users_trader_id_index` (`trader_id`);

--
-- Indizes für die Tabelle `user_chats`
--
ALTER TABLE `user_chats`
 ADD PRIMARY KEY (`id`), ADD KEY `user_chats_user_from_id_foreign` (`user_from_id`), ADD KEY `user_chats_user_to_id_foreign` (`user_to_id`);

--
-- Indizes für die Tabelle `user_chat_leads`
--
ALTER TABLE `user_chat_leads`
 ADD PRIMARY KEY (`id`), ADD KEY `user_chat_leads_user_chat_id_foreign` (`user_chat_id`), ADD KEY `user_chat_leads_lead_id_foreign` (`lead_id`);

--
-- Indizes für die Tabelle `user_chat_messages`
--
ALTER TABLE `user_chat_messages`
 ADD PRIMARY KEY (`id`), ADD KEY `user_chat_messages_user_chat_id_foreign` (`user_chat_id`), ADD KEY `user_chat_messages_user_from_id_foreign` (`user_from_id`), ADD KEY `user_chat_messages_user_to_id_foreign` (`user_to_id`);

--
-- Indizes für die Tabelle `user_chat_message_documents`
--
ALTER TABLE `user_chat_message_documents`
 ADD PRIMARY KEY (`id`), ADD KEY `user_chat_message_documents_user_chat_message_id_foreign` (`user_chat_message_id`);

--
-- Indizes für die Tabelle `user_childs`
--
ALTER TABLE `user_childs`
 ADD PRIMARY KEY (`id`), ADD KEY `user_childs_user_parent_id_foreign` (`user_parent_id`), ADD KEY `user_childs_user_child_id_foreign` (`user_child_id`);

--
-- Indizes für die Tabelle `user_invites`
--
ALTER TABLE `user_invites`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `user_invites_email_unique` (`email`), ADD UNIQUE KEY `user_invites_code_unique` (`code`), ADD KEY `user_invites_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `access_rights`
--
ALTER TABLE `access_rights`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT für Tabelle `access_roles`
--
ALTER TABLE `access_roles`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT für Tabelle `access_role_user`
--
ALTER TABLE `access_role_user`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=291;
--
-- AUTO_INCREMENT für Tabelle `jobs`
--
ALTER TABLE `jobs`
MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `leads`
--
ALTER TABLE `leads`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=658;
--
-- AUTO_INCREMENT für Tabelle `leads_articles`
--
ALTER TABLE `leads_articles`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1445;
--
-- AUTO_INCREMENT für Tabelle `leads_documents`
--
ALTER TABLE `leads_documents`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `leads_images`
--
ALTER TABLE `leads_images`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `leads_offers`
--
ALTER TABLE `leads_offers`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `leads_offers_documents`
--
ALTER TABLE `leads_offers_documents`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `leads_sellers`
--
ALTER TABLE `leads_sellers`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2531;
--
-- AUTO_INCREMENT für Tabelle `migrations`
--
ALTER TABLE `migrations`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1103;
--
-- AUTO_INCREMENT für Tabelle `navigation`
--
ALTER TABLE `navigation`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT für Tabelle `profiles`
--
ALTER TABLE `profiles`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=118;
--
-- AUTO_INCREMENT für Tabelle `projects`
--
ALTER TABLE `projects`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=242;
--
-- AUTO_INCREMENT für Tabelle `tree`
--
ALTER TABLE `tree`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT für Tabelle `tree_node`
--
ALTER TABLE `tree_node`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT für Tabelle `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=142;
--
-- AUTO_INCREMENT für Tabelle `user_chats`
--
ALTER TABLE `user_chats`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `user_chat_leads`
--
ALTER TABLE `user_chat_leads`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `user_chat_messages`
--
ALTER TABLE `user_chat_messages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `user_chat_message_documents`
--
ALTER TABLE `user_chat_message_documents`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `user_childs`
--
ALTER TABLE `user_childs`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT für Tabelle `user_invites`
--
ALTER TABLE `user_invites`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `access_rights`
--
ALTER TABLE `access_rights`
ADD CONSTRAINT `access_rights_access_role_id_foreign` FOREIGN KEY (`access_role_id`) REFERENCES `access_roles` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `access_role_user`
--
ALTER TABLE `access_role_user`
ADD CONSTRAINT `access_role_user_access_role_id_foreign` FOREIGN KEY (`access_role_id`) REFERENCES `access_roles` (`id`) ON DELETE CASCADE,
ADD CONSTRAINT `access_role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `leads`
--
ALTER TABLE `leads`
ADD CONSTRAINT `leads_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
ADD CONSTRAINT `leads_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `leads_articles`
--
ALTER TABLE `leads_articles`
ADD CONSTRAINT `leads_articles_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `leads_documents`
--
ALTER TABLE `leads_documents`
ADD CONSTRAINT `leads_documents_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `leads_images`
--
ALTER TABLE `leads_images`
ADD CONSTRAINT `leads_images_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `leads_offers`
--
ALTER TABLE `leads_offers`
ADD CONSTRAINT `leads_offers_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
ADD CONSTRAINT `leads_offers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `leads_offers_documents`
--
ALTER TABLE `leads_offers_documents`
ADD CONSTRAINT `leads_offers_documents_lead_offer_id_foreign` FOREIGN KEY (`lead_offer_id`) REFERENCES `leads_offers` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `leads_sellers`
--
ALTER TABLE `leads_sellers`
ADD CONSTRAINT `leads_sellers_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
ADD CONSTRAINT `leads_sellers_user_id_contact_foreign` FOREIGN KEY (`user_id_contact`) REFERENCES `users` (`id`) ON DELETE CASCADE,
ADD CONSTRAINT `leads_sellers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `navigation`
--
ALTER TABLE `navigation`
ADD CONSTRAINT `navigation_tree_node_foreign` FOREIGN KEY (`tree_node`) REFERENCES `tree_node` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `profiles`
--
ALTER TABLE `profiles`
ADD CONSTRAINT `profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `projects`
--
ALTER TABLE `projects`
ADD CONSTRAINT `projects_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `tree_node`
--
ALTER TABLE `tree_node`
ADD CONSTRAINT `tree_node_parent_foreign` FOREIGN KEY (`parent`) REFERENCES `tree_node` (`id`) ON DELETE CASCADE,
ADD CONSTRAINT `tree_node_tree_foreign` FOREIGN KEY (`tree`) REFERENCES `tree` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `user_chats`
--
ALTER TABLE `user_chats`
ADD CONSTRAINT `user_chats_user_from_id_foreign` FOREIGN KEY (`user_from_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
ADD CONSTRAINT `user_chats_user_to_id_foreign` FOREIGN KEY (`user_to_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `user_chat_leads`
--
ALTER TABLE `user_chat_leads`
ADD CONSTRAINT `user_chat_leads_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
ADD CONSTRAINT `user_chat_leads_user_chat_id_foreign` FOREIGN KEY (`user_chat_id`) REFERENCES `user_chats` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `user_chat_messages`
--
ALTER TABLE `user_chat_messages`
ADD CONSTRAINT `user_chat_messages_user_chat_id_foreign` FOREIGN KEY (`user_chat_id`) REFERENCES `user_chats` (`id`) ON DELETE CASCADE,
ADD CONSTRAINT `user_chat_messages_user_from_id_foreign` FOREIGN KEY (`user_from_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
ADD CONSTRAINT `user_chat_messages_user_to_id_foreign` FOREIGN KEY (`user_to_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `user_chat_message_documents`
--
ALTER TABLE `user_chat_message_documents`
ADD CONSTRAINT `user_chat_message_documents_user_chat_message_id_foreign` FOREIGN KEY (`user_chat_message_id`) REFERENCES `user_chat_messages` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `user_childs`
--
ALTER TABLE `user_childs`
ADD CONSTRAINT `user_childs_user_child_id_foreign` FOREIGN KEY (`user_child_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
ADD CONSTRAINT `user_childs_user_parent_id_foreign` FOREIGN KEY (`user_parent_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `user_invites`
--
ALTER TABLE `user_invites`
ADD CONSTRAINT `user_invites_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
